from django.apps import AppConfig


class SignupinConfig(AppConfig):
    name = 'SignUpIn'
